using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Data.SqlClient;
using System.Threading;
using System.ComponentModel.Design;
using System.IO;

namespace TresRaya
{
    public partial class Menu : Form
    {
        //Variables globales
        Socket server;
        Thread atender;
        int puerto = 9084;
        int terminar = 0;
        string anfitrion;
        string usr;
        string invitado;
        int num_inivtados;
        public StreamWriter STW;
        delegate void DelegadoParaEscribir(string Text); //Nos permite escribir la respuesta del servidor
        Invitacion Invitacion = new Invitacion(); //Para poder acceder al formulario de la invitacion 
        private Form2 Demo;

        public Menu()
        {
            InitializeComponent();
            log_contra.PasswordChar = '*';
            log_usuario.MaxLength = 30;
            log_contra.MaxLength = 30;

        }

        private void Menu_Load(object sender, EventArgs e)
        {
            TablaConectados.ColumnCount = 1;
            TablaConectados.RowCount = 100;
            TablaConectados.ColumnHeadersVisible = false;
            TablaConectados.RowHeadersVisible = false;
            TablaConectados.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

        }

//-----------Metodos que haremos servir para atender al servidor

        public string DameUsuario { set { log_usuario.Text = value; } }
        public string PonUsuario { get { return log_usuario.Text; } }

        public string DameOponente { set { this.anfitrion= value; } }

        public string PonOponente { get { return this.anfitrion; } }
        public void PonRespuesta (string Texto)
        {
            MessageBox.Show(Texto); //Recojemos con esto la respuesta por parte del servidor
        }
        private void Registrarse_Click(object sender, EventArgs e)
        { 
            //Creamos un IPEndPoint con el ip del servidor y puerto del servidor 
            //al que deseamos conectarnos
            IPAddress direc = IPAddress.Parse("192.168.56.101");
            IPEndPoint ipep = new IPEndPoint(direc, puerto);


            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);//Intentamos conectar el socket
                this.BackColor = Color.LightGreen;
                MessageBox.Show("Conectado");



            }
            catch (SocketException ex)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }
            string mensaje_nuevo = "1/" + nuevo_usuario.Text + "/" + nuevo_contra.Text + "/";
            // Enviamos al servidor el nombre el user y la contrase�a
            byte[] msg_nuevo = System.Text.Encoding.ASCII.GetBytes(mensaje_nuevo);
            server.Send(msg_nuevo);

        }


        private void Conectar_Click(object sender, EventArgs e)
        {

            //Nos conectamos con el servidor 
            IPAddress direccion = IPAddress.Parse("192.168.56.101");
            IPEndPoint ipep = new IPEndPoint(direccion, puerto);

            string nombre = nuevo_usuario.Text.Trim();

            //Creamos el socket para el cliente 

            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            try
            {
                server.Connect(ipep);               //Intentamos conectar el socket
                this.BackColor = Color.LightGreen;
                MessageBox.Show("Conectado");

            }
            catch (SocketException ex)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }

            //Una vez conectados con el servidor iniciamos sesion con nuestro usuario
            if ((nuevo_usuario != null) && (nuevo_contra != null))
            {
                string mensaje = ("2/" + log_usuario.Text + "/" + log_contra.Text + "/");
                // Enviamos al servidor el nombre el user y la contrase�a
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                ThreadStart ts = delegate
                {
                    AtenderServidor();

                };
                atender = new Thread(ts);
                atender.Start();

            }
            }

        public void MuestraConectados(string conectados)
        {
            int i;
            string[] lista = conectados.Split(',');
            for (i = 0; i < 100; i++)
            {
                TablaConectados.Rows[i].Cells[0].Value = "";
            }
            for (int k = 0; k <= lista.Length - 1; k++)
            {
                TablaConectados.Rows[k].Cells[0].Value = lista[k];
            }
        }

        public void DameConectados()
        {
            string mensaje = "6/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }


        private void Desconectar_Click(object sender, EventArgs e)
        {
            try
            {
                // Enviar un mensaje de desconexi�n al servidor
                string mensaje = "0/" + log_usuario.Text + "/";
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                // Cerrar la conexi�n
                 server.Shutdown(SocketShutdown.Both);
                 server.Close();
                 terminar = 1;
                 this.BackColor = Color.Gray;

                // Cerrar el formulario
                 this.Close();
                

            }
            catch (Exception ex)
            {
                // Manejar cualquier excepci�n que pueda ocurrir durante la desconexi�n
                MessageBox.Show("Error al desconectar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        //Para implemntar el servicio de invitacion 

        public void PonInvitado(string invitado)
        {
            this.invitado = invitado;
        }

        public string DameInvitado() //Nos devuelve el nombre del invitado seleccionado 
        {
            return this.invitado;   
        }

        private void button4_Click(object sender, EventArgs e) //Enviamos la peticion de invitacion al servidor
        {
            MessageBox.Show("Seleccione con cual de los jugadores de lista de conectados desea jugar");
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            TablaConectados.CurrentCell.Style.BackColor = Color.Pink;
            int i, j;
            i = e.RowIndex;
            j = e.ColumnIndex;
            //Una vez seleccionamos el nombre del jugador se lo enviamos al servidor para que este le envie la invitacion
            string mensaje = ("7/" + log_usuario.Text + "/"+ TablaConectados.Rows[i].Cells[j].Value.ToString()); // 7/Anfitrion/invitado
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
            
        }

        //Funciones de cara a lo que viene a ser la parte del juego 
        
        public void ActualizarTableroEventHandler(string posicion)
        {
            // Tu l�gica para manejar el evento aqu�
            // Puedes acceder a los datos de posici�n y realizar acciones necesarias
        }
        public void SolicitudRec(string invitador)
        {
            this.anfitrion = invitador.Trim();

            int r;
            MessageBox.Show(invitador + " te ha invitado a una partida presiona en aceptar o denegar para responder a su solicitud");
            Invitacion.ShowDialog();
            r = Invitacion.GetResp();

            if (r == 0) // Se acepta la solicitud
            {
                string mensaje = ("8/" + r + "/" + anfitrion  + "/" + log_usuario.Text); //Damos al servidor 8/respuesta/anfitrion/invitado 
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                // Crea la instancia de Form2 solo si la respuesta es aceptada
                Demo = new Form2(this, server);
                Demo.ActualizarTableroEvent += ActualizarTableroEventHandler;
            }
            if (r == 1) // Se deniega la solicitud
            {
                string mensaje = "8/" + r;
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }

        }

        private void Cerrar_Sesion_Click(object sender, EventArgs e)    //Me desconecto con el usuario que tengo 
        {
            string mensaje = ("9/" + log_usuario.Text + "/");
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
          
        }

        private void Darme_Baja_Click(object sender, EventArgs e) //Elimino mi usuario
        {
            string mensaje = "10/" + log_usuario.Text + "/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void button1_Click(object sender, EventArgs e) //Consulta1
        {
            string mensaje = "3/" + log_usuario.Text + "/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }
        private void button2_Click(object sender, EventArgs e) //Consulta2
        {
            string mensaje = "4/" + oponente.Text + "/" +  log_usuario.Text + "/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

        }

      
       
//------------FUNCION PARA ATENDER RESPUESTAS DEL SERVIDOR A LAS CONSULTAS
        private void AtenderServidor()
        {
            try
            {
                while (terminar != 1)
                {
                    int err;
                    //Recibimos la respuesta por parte del servidor 
                    byte[] msg2 = new byte[80];
                    string[] ms3;
                    // recibo mensaje del servidor
                    server.Receive(msg2);
                    string mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                    string[] trozos = mensaje.Split('/');
                    int op = Convert.ToInt32(trozos[0]); //Convertimo el trozo de la cadena en un entero
                                                         // Recibimos mensaje del servidor
                    switch (op)
                    {


                        case 1: //Registrarme como nuevo usuario 

                            {
                                string respuesta;
                                err = Convert.ToInt32(trozos[1]); //Vemos si se ha conseguido registrar el nuevo usuario

                                if (err == 0)  //No se ha conseguido registrar en la base de datos 
                                {
                                    respuesta = "Error al consultar la base de datos";
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] {respuesta});
                                }

                                if (err == 1)
                                {
                                    respuesta = "Se ha registrado conrrectamente";
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] {respuesta});
                                    //Una vez conseguimos iniciar sesion mostramos la tabla de conectados 
                                }

                                break;
                            }
                        case 2: //Iniciar sesion

                            {
                                string respuesta;
                                err = Convert.ToInt32(trozos[1]); //vemos si se ha conseguido iniciar sesion correctamente 

                                if (err == 0)  //No se ha conseguido registrar en la base de datos 
                                {
                                    respuesta = "No se ha podido iniciar sesion correctamente";
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] {respuesta});

                                }

                                else if (err == 1) //Se ha conseguido iniciar sesio 
                                {
                                    respuesta = "Se ha iniciado sesion";
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] { respuesta });
                                    //Solicitamos la lista de usuarios conectados 
                                    DameConectados();

                                }

                                break;
                            }
                        case 3: //Devuelva la lista con todos los jugadores con quienes he jugado
                            {
                                err = Convert.ToInt32(trozos[1]);
                                string respuesta;
                                if(err==1)
                                {
                                    respuesta = "Error al consulta la base de datos";
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] {respuesta});
                                }
                                else if(err==2)
                                {
                                    respuesta = "No se han hecho de momento ninguna partida";
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] {respuesta});
                                }

                                else if(err==0)
                                {
                                    respuesta = "Jugadores con quienes has competido" + trozos[2];
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] { respuesta });
                                }
                                break;
                            }

                        case 4: //Devuelve los datos de la partida 
                            {
                                err = Convert.ToInt32(trozos[1]);
                                string respuesta;
                                if (err == 1)
                                {
                                    respuesta = "Error al consulta la base de datos";
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] { respuesta });
                                }
                                else if (err == 2)
                                {
                                    respuesta = "No se ha hecho de momento ninguna partida";
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] { respuesta });
                                }

                                else if (err == 0)
                                {
                                    respuesta = "Ganador: " + trozos[2];
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] { respuesta });
                                }
                                break;
                            }
                        case 5: //Consulta 3
                            {
                                break;
                            }
                        case 6: //De forma automatica se nos da la lista con los usuarios conectados
                            {
                                //recibimos como respuesta la lista y lo ponemos en la funcion de muestra conectados para poder visualizar
                                //en el datagrid de Tabla de Conectados

                                string conectados = trozos[1]; //usuario1,usuario2,usuario3.....

                                DelegadoParaEscribir del = new DelegadoParaEscribir(MuestraConectados);
                                this.Invoke(del, new Object[] { conectados});  
                                break;
                            }

                        case 7: //Recibimos la solicitud de juego 
                            {
                                
                                this.Invoke(new DelegadoParaEscribir(SolicitudRec), new object[] { trozos[1]});
                                break;
                            }
                        case 8: //Aceptacion de la invitacion
                            {
                                this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] { "Solicitud aceptada" });
                                this.Invoke(new DelegadoParaEscribir(PonInvitado), new object[] { trozos[1] });
                                MessageBox.Show("Empieza la partida");

                                // Cierra el formulario de invitaci�n en el hilo principal
                                this.Invoke(new Action(() =>
                                {
                                    Invitacion.Close();
                                }));

                                if (Demo != null)
                                {
                                    // C�digo para iniciar el juego
                                    Form2 Demo = new Form2(this, server);
                                    Demo.ShowDialog();

                                }
                                break;
                            }
                        case 9: //Rechazo de la invitacion
                            {
                                err = Convert.ToInt32(trozos[1]);
                                if(err==0)
                                {
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] { "Solo pueden ser dos jugadores" });
                                    //Una vez se acepta la solictud se empieza el juego 
                                    
                                }
                                if(err==1)
                                {
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] { "Solicitud rechazada" });
                                }
                                break;
                            }

                        case 10: //Cerrar Sesion 
                            {

                                DameConectados();
                                break;
                            }
                        case 12: //Notificacion de la desconexion de uno de los usuarios a todos 
                            {
                              
                                DameConectados();
                                MessageBox.Show("se ha desconectado uno de los jugadores");
                                break;
                            }
                        case 14: //Piezas del juego 
                            {
                                //Notificamos al formulario del tablero la actualizacion de las fichas 
                                // Procesar la informaci�n recibida
                                this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] { trozos[1] });

                                // Aseg�rate de tener una instancia v�lida de Form2
                               

                                /*
                                      if (trozos[1] == "A1")
                                      {
                                        //Ponemos ficha oponente
                                         Demo.PonA1 = "0";
                                         Demo.EstadoA1 = false; //bloqueamos bo

                                      }
                                      if (trozos[1] == "A2")
                                      {
                                          Demo.PonA2 = "A2";
                                          Demo.EstadoA2 = false;
                                          
                                      }
                                      if (trozos[1] == "A3")
                                      {
                                          Demo.PonA3 = "A3";
                                          Demo.EstadoA3 = false;
                                          
                                      }
                                      if (trozos[1] == "B1")
                                      {
                                          
                                          Demo.PonB1 = "O";
                                          Demo.EstadoB1 = false;

                                      }
                                      if (trozos[1] == "B2")
                                      {
                                         Demo.PonB2 = "0";
                                         Demo.EstadoB2 = false;
                                      }
                                      if (trozos[1] == "B3")
                                      {
                                          Demo.PonB3 = "0";
                                          Demo.EstadoB3 = false;

                                      }
                                      if (trozos[1] == "C1")
                                      {
                                          Demo.PonC1 = "0";
                                          Demo.EstadoC1 = false;

                                      }
                                      if (trozos[1] == "C2")
                                      {
                                            Demo.PonC2 = "0";
                                            Demo.EstadoC2 = false;

                                      }
                                      if (trozos[1] == "C3")
                                      {
                                          Demo.PonC3 = "0";
                                          Demo.EstadoC3 = false;
                                      }
                                   */  
                                break;
                            }

                        case 15:    //Enviamos al servidor quien ha sido el ganador de la partida
                            {
                                break;
                            }
                        case 11:  //Eliminar un usuario 
                            {
                                err= Convert.ToInt32(trozos[1]);
                                if(err==0)
                                {
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] {"Error al consultar la base de datos"});
                                }

                                if(err==1)
                                {
                                    this.Invoke(new DelegadoParaEscribir(PonRespuesta), new object[] {"Se ha dado de baja correctamente"});
                                    DameConectados();
                                }
                                break;
                            }
                            default:
                            break;
                      
                    }
                    
                }
                  
            }

            catch (SocketException) { }
            
        }



       










        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Jugar_Click(object sender, EventArgs e)
        {
            //Demo.Show(); //Una vez se ha aceptado la partida podemos empezar a jugar contra el jugsdor
        }
    }
}