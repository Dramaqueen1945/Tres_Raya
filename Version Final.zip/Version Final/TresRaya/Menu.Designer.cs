﻿namespace TresRaya
{
    partial class Menu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.oponente = new System.Windows.Forms.TextBox();
            this.Jugar = new System.Windows.Forms.Button();
            this.Darme_Baja = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.Cerrar_Sesion = new System.Windows.Forms.Button();
            this.Registrarse = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.TablaConectados = new System.Windows.Forms.DataGridView();
            this.Invi = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Desconectar = new System.Windows.Forms.Button();
            this.Conectar = new System.Windows.Forms.Button();
            this.nuevo_contra = new System.Windows.Forms.TextBox();
            this.nuevo_usuario = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.log_contra = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.log_usuario = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TablaConectados)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.oponente);
            this.groupBox1.Controls.Add(this.Jugar);
            this.groupBox1.Controls.Add(this.Darme_Baja);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.Cerrar_Sesion);
            this.groupBox1.Controls.Add(this.Registrarse);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.TablaConectados);
            this.groupBox1.Controls.Add(this.Invi);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.Desconectar);
            this.groupBox1.Controls.Add(this.Conectar);
            this.groupBox1.Controls.Add(this.nuevo_contra);
            this.groupBox1.Controls.Add(this.nuevo_usuario);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.log_contra);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.log_usuario);
            this.groupBox1.Font = new System.Drawing.Font("Constantia", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(1, 72);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1165, 760);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MENU";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter_1);
            // 
            // oponente
            // 
            this.oponente.Font = new System.Drawing.Font("Constantia", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.oponente.Location = new System.Drawing.Point(380, 329);
            this.oponente.Name = "oponente";
            this.oponente.Size = new System.Drawing.Size(169, 37);
            this.oponente.TabIndex = 24;
            // 
            // Jugar
            // 
            this.Jugar.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Jugar.Location = new System.Drawing.Point(839, 614);
            this.Jugar.Name = "Jugar";
            this.Jugar.Size = new System.Drawing.Size(253, 68);
            this.Jugar.TabIndex = 2;
            this.Jugar.Text = "Jugar";
            this.Jugar.UseVisualStyleBackColor = true;
            this.Jugar.Click += new System.EventHandler(this.Jugar_Click);
            // 
            // Darme_Baja
            // 
            this.Darme_Baja.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Darme_Baja.Location = new System.Drawing.Point(85, 672);
            this.Darme_Baja.Name = "Darme_Baja";
            this.Darme_Baja.Size = new System.Drawing.Size(151, 34);
            this.Darme_Baja.TabIndex = 23;
            this.Darme_Baja.Text = "Darme Baja";
            this.Darme_Baja.UseVisualStyleBackColor = true;
            this.Darme_Baja.Click += new System.EventHandler(this.Darme_Baja_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Constantia", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(18, 519);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(145, 27);
            this.label11.TabIndex = 22;
            this.label11.Text = "Desconexion";
            // 
            // Cerrar_Sesion
            // 
            this.Cerrar_Sesion.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Cerrar_Sesion.Location = new System.Drawing.Point(85, 614);
            this.Cerrar_Sesion.Name = "Cerrar_Sesion";
            this.Cerrar_Sesion.Size = new System.Drawing.Size(151, 34);
            this.Cerrar_Sesion.TabIndex = 21;
            this.Cerrar_Sesion.Text = "Cerrar Sesion";
            this.Cerrar_Sesion.UseVisualStyleBackColor = true;
            this.Cerrar_Sesion.Click += new System.EventHandler(this.Cerrar_Sesion_Click);
            // 
            // Registrarse
            // 
            this.Registrarse.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Registrarse.Location = new System.Drawing.Point(685, 196);
            this.Registrarse.Name = "Registrarse";
            this.Registrarse.Size = new System.Drawing.Size(112, 34);
            this.Registrarse.TabIndex = 20;
            this.Registrarse.Text = "Registrar";
            this.Registrarse.UseVisualStyleBackColor = true;
            this.Registrarse.Click += new System.EventHandler(this.Registrarse_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(432, 478);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(219, 24);
            this.label10.TabIndex = 19;
            this.label10.Text = "Jugadores Conectados";
            // 
            // TablaConectados
            // 
            this.TablaConectados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TablaConectados.Location = new System.Drawing.Point(369, 519);
            this.TablaConectados.Name = "TablaConectados";
            this.TablaConectados.RowHeadersWidth = 62;
            this.TablaConectados.RowTemplate.Height = 33;
            this.TablaConectados.Size = new System.Drawing.Size(360, 225);
            this.TablaConectados.TabIndex = 18;
            this.TablaConectados.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Invi
            // 
            this.Invi.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Invi.Location = new System.Drawing.Point(30, 395);
            this.Invi.Name = "Invi";
            this.Invi.Size = new System.Drawing.Size(143, 45);
            this.Invi.TabIndex = 17;
            this.Invi.Text = "Invitacion";
            this.Invi.UseVisualStyleBackColor = true;
            this.Invi.Click += new System.EventHandler(this.button4_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Constantia", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(19, 265);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(123, 27);
            this.label8.TabIndex = 16;
            this.label8.Text = "Consultas:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(207, 538);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 35);
            this.label7.TabIndex = 15;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(19, 318);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(343, 48);
            this.button2.TabIndex = 13;
            this.button2.Text = "Resultados de la partida contra: ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(685, 324);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(399, 48);
            this.button1.TabIndex = 12;
            this.button1.Text = "Jugadores con los que tuve una partida";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Desconectar
            // 
            this.Desconectar.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Desconectar.Location = new System.Drawing.Point(85, 565);
            this.Desconectar.Name = "Desconectar";
            this.Desconectar.Size = new System.Drawing.Size(144, 34);
            this.Desconectar.TabIndex = 11;
            this.Desconectar.Text = "Desconectar";
            this.Desconectar.UseVisualStyleBackColor = true;
            this.Desconectar.Click += new System.EventHandler(this.Desconectar_Click);
            // 
            // Conectar
            // 
            this.Conectar.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Conectar.Location = new System.Drawing.Point(248, 199);
            this.Conectar.Name = "Conectar";
            this.Conectar.Size = new System.Drawing.Size(112, 34);
            this.Conectar.TabIndex = 10;
            this.Conectar.Text = "Conectar";
            this.Conectar.UseVisualStyleBackColor = true;
            this.Conectar.Click += new System.EventHandler(this.Conectar_Click);
            // 
            // nuevo_contra
            // 
            this.nuevo_contra.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.nuevo_contra.Location = new System.Drawing.Point(729, 147);
            this.nuevo_contra.Name = "nuevo_contra";
            this.nuevo_contra.Size = new System.Drawing.Size(151, 32);
            this.nuevo_contra.TabIndex = 9;
            // 
            // nuevo_usuario
            // 
            this.nuevo_usuario.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.nuevo_usuario.Location = new System.Drawing.Point(729, 106);
            this.nuevo_usuario.Name = "nuevo_usuario";
            this.nuevo_usuario.Size = new System.Drawing.Size(151, 32);
            this.nuevo_usuario.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(598, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 24);
            this.label6.TabIndex = 7;
            this.label6.Text = "Contraseña:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(598, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 24);
            this.label5.TabIndex = 6;
            this.label5.Text = "Nombre:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Constantia", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(223, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 27);
            this.label4.TabIndex = 5;
            this.label4.Text = "Iniciar Sesion";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Constantia", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(685, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 27);
            this.label3.TabIndex = 4;
            this.label3.Text = "Registrarse";
            // 
            // log_contra
            // 
            this.log_contra.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.log_contra.Location = new System.Drawing.Point(294, 147);
            this.log_contra.Name = "log_contra";
            this.log_contra.Size = new System.Drawing.Size(151, 32);
            this.log_contra.TabIndex = 3;
            this.log_contra.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(163, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Contraseña:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(161, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombre:";
            // 
            // log_usuario
            // 
            this.log_usuario.Font = new System.Drawing.Font("Constantia", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.log_usuario.Location = new System.Drawing.Point(294, 109);
            this.log_usuario.Name = "log_usuario";
            this.log_usuario.Size = new System.Drawing.Size(151, 32);
            this.log_usuario.TabIndex = 0;
            this.log_usuario.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Malgun Gothic", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(321, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(502, 48);
            this.label9.TabIndex = 3;
            this.label9.Text = "Bienvenido al Tres en Raya!";
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1178, 844);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox1);
            this.Name = "Menu";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TablaConectados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox groupBox1;
        private TextBox log_usuario;
        private TextBox log_contra;
        private Label label2;
        private Label label1;
        private Label label4;
        private Label label3;
        private Label label10;
        private DataGridView TablaConectados;
        private Button Invi;
        private Label label8;
        private Label label7;
        private Button button2;
        private Button button1;
        private Button Desconectar;
        private Button Conectar;
        private TextBox nuevo_contra;
        private TextBox nuevo_usuario;
        private Label label6;
        private Label label5;
        private Button Jugar;
        private Label label9;
        private Button Registrarse;
        private Label label11;
        private Button Cerrar_Sesion;
        private Button Darme_Baja;
        private TextBox oponente;
    }
}