﻿namespace TresRaya
{
    partial class Invitacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.aceptar = new System.Windows.Forms.Button();
            this.rechazar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // aceptar
            // 
            this.aceptar.Location = new System.Drawing.Point(51, 79);
            this.aceptar.Name = "aceptar";
            this.aceptar.Size = new System.Drawing.Size(112, 34);
            this.aceptar.TabIndex = 0;
            this.aceptar.Text = "aceptar";
            this.aceptar.UseVisualStyleBackColor = true;
            this.aceptar.Click += new System.EventHandler(this.aceptar_Click_1);
            // 
            // rechazar
            // 
            this.rechazar.Location = new System.Drawing.Point(280, 79);
            this.rechazar.Name = "rechazar";
            this.rechazar.Size = new System.Drawing.Size(112, 34);
            this.rechazar.TabIndex = 1;
            this.rechazar.Text = "rechazar";
            this.rechazar.UseVisualStyleBackColor = true;
            this.rechazar.Click += new System.EventHandler(this.button2_Click);
            // 
            // Invitacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 244);
            this.Controls.Add(this.rechazar);
            this.Controls.Add(this.aceptar);
            this.Name = "Invitacion";
            this.Text = "Invitacion";
            this.Load += new System.EventHandler(this.Invitacion_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Button aceptar;
        private Button rechazar;
    }
}