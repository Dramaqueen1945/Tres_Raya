﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Data.SqlClient;
using System.Threading;
using System.ComponentModel.Design;
using System.IO;

namespace TresRaya
{
    public partial class Form2 : Form    //Definimos el tablero mediante buttons 
    {

        string casilla;
        private Menu menu; //Variable para almacenar la referencia al Menu
        private Socket server; //Variable para almacenar la referencia al objeto server 
      
        public Form2(Menu menu, Socket server)
        {
            InitializeComponent();
            this.menu = menu; //Almacena la referencia a Menu
            this.server = server; //Almacena la referencia al objeto server 
            
        }
        
        //Hemos de tener en cuenta que estamo usando otro formulario para que nuestro servidor tambien pueda atender nuestras
        //en cuanto lo que viene a ser el juego 
        private void Form2_Load(object sender, EventArgs e)
        {
            
            //Aqui podemos que inicialmente el valor de todas las casillas estan disponibles
            A1.Enabled = true;
            A2.Enabled = true;  
            A3.Enabled = true;
            B1.Enabled = true;
            B2.Enabled = true;
            B3.Enabled = true;
            C1.Enabled = true;
            C2.Enabled = true;
            C3.Enabled = true;
            

        }

        //Con esto se nos devuelve el nombre que tienen las casillas para ponerlo disponible o no
       

       
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        bool ekis = true;   //true= X 
        int ekis_count = 0;

        
        private void A1_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (ekis)
                b.Text = "X";
            
            else
                b.Text = "O";
            
            ekis = !ekis;
            A1.Enabled = false;  //pq no es pugui tornar a clicar
            ekis_count++;
            try
            {
                string mensaje = "14" + "/" + "A1" + "/" + menu.PonOponente; //14/A1/anfitrion
                EnviaMensajeServidor(mensaje);
              
            }
            catch
            {
            }
            GanadorPartida();
           
            
        }

        private void A2_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (ekis)
                b.Text = "X";
            
            else
                b.Text = "O";
            
            ekis = !ekis;
            A2.Enabled = false;  //pq no es pugui tornar a clicar
            ekis_count++;
            
            try
            {
                string mensaje = "14" +"/" + "A2" + "/" + menu.PonOponente; //14/A1/anfitrion/usuario;
                EnviaMensajeServidor(mensaje);
            }
            catch
            {
            }
            
            GanadorPartida();
            
           
        }

        private void A3_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (ekis)
                b.Text = "X";
            
            else
                b.Text = "O";
            
            ekis = !ekis;
            A3.Enabled = false;  //pq no es pugui tornar a clicar
            ekis_count++;
            
            try
            {
                string mensaje = "14/A3" + "/" + menu.PonOponente;
                EnviaMensajeServidor(mensaje);
            }
            catch
            {
            }
            GanadorPartida();
            
        }

        private void B1_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (ekis)
                b.Text = "X";
            
            else
               b.Text = "O";
            
            ekis = !ekis;
            B1.Enabled = false;  //pq no es pugui tornar a clicar
            ekis_count++;
            
            try
            {
                string mensaje = "14/B1" + "/" + menu.PonOponente;
                EnviaMensajeServidor(mensaje);
            }
            catch
            {
            }
            
            GanadorPartida();
            
        }

        private void B2_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (ekis)
                b.Text = "X";
            
            else
                b.Text = "O";
            
            ekis = !ekis;
            B2.Enabled = false;  //pq no es pugui tornar a clicar
            ekis_count++;
            
            try
            {
                string mensaje = "14/B2" + "/" + menu.PonOponente;   
                EnviaMensajeServidor(mensaje);
            }
            catch
            {
            }
            GanadorPartida();
            
        }

        private void B3_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (ekis)
                b.Text = "X";
            
            else
               b.Text = "O";
            
            ekis = !ekis;
            B3.Enabled = false;  //pq no es pugui tornar a clicar
            ekis_count++;
            
            try
            {
                string mensaje = "14/B3" + "/" + menu.PonOponente;   
                EnviaMensajeServidor(mensaje);
            }
            catch
            {
            }
            
            GanadorPartida();
            
        }

        private void C1_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (ekis)
                b.Text = "X";
            
            else
               b.Text = "O";
            
            ekis = !ekis;
            C1.Enabled = false;  //pq no es pugui tornar a clicar
            ekis_count++;
            
            try
            {
                string mensaje = "14/C1" + "/" + menu.PonOponente;
                EnviaMensajeServidor(mensaje);
                
            }
            catch
            {
            }
            
            GanadorPartida();
            
        }

        private void C2_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (ekis)
                b.Text = "X";
            else
               b.Text = "O";

            ekis = !ekis;
            C2.Enabled = false;  //pq no es pugui tornar a clicar
            ekis_count++;
            

            try
            {
               
                string mensaje = "14/C2" + "/" + menu.PonOponente;
                EnviaMensajeServidor(mensaje);
            }
            catch
            {
            }
            GanadorPartida();
            
        }

        private void C3_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (ekis)
                b.Text = "X";
            
            else
                b.Text = "O";
            
            ekis = !ekis;
            C3.Enabled = false;  //pq no es pugui tornar a clicar
            ekis_count++;
            
            try
            {
                string mensaje = "14/C3" + "/" + menu.PonOponente;   //
                EnviaMensajeServidor(mensaje);
            }
            catch
            {
            }  
            GanadorPartida();
            
        }

        
        private void GanadorPartida()       //REGLAS PARA GANAR
        {
            bool ganador = false;
            //hoitzontals
            if ((A1.Text == "X") && (A2.Text == "X") && (A3.Text == "X") && (!A1.Enabled))
                ganador = true;
            else if ((B1.Text == "X") && (B2.Text == "X") && (B3.Text == "X") && (!B1.Enabled))
                ganador = true;
            else if ((C1.Text == "X") && (C2.Text == "X") && (C3.Text == "X") && (!C1.Enabled))
                ganador = true;
            //diagonals
            else if ((A1.Text == "X") && (B2.Text == "X") && (C3.Text == "X") && (!A1.Enabled))
                ganador = true;
            else if ((A3.Text == "X") && (B2.Text == "X") && (C1.Text == "X") && (!A3.Enabled))
                ganador = true;
            //columnes
            else if ((A1.Text == "X") && (B1.Text == "X") && (C1.Text == "X") && (!A1.Enabled))
                ganador = true;
            else if ((A2.Text == "X") && (B2.Text == "X") && (C2.Text == "X") && (!A2.Enabled))
                ganador = true;
            else if ((A3.Text == "X") && (B3.Text == "X") && (C3.Text == "X") && (!A3.Enabled))
                ganador = true;
            //hoitzontals con O
            if ((A1.Text == "O") && (A2.Text == "O") && (A3.Text == "O") && (!A1.Enabled))
                ganador = true;
            else if ((B1.Text == "O") && (B2.Text == "O") && (B3.Text == "O") && (!B1.Enabled))
                ganador = true;
            else if ((C1.Text == "O") && (C2.Text == "O") && (C3.Text == "O") && (!C1.Enabled))
                ganador = true;
            //diagonals
            else if ((A1.Text == "O") && (B2.Text == "O") && (C3.Text == "O") && (!A1.Enabled))
                ganador = true;
            else if ((A3.Text == "O") && (B2.Text == "O") && (C1.Text == "O") && (!A3.Enabled))
                ganador = true;
            //columnes
            else if ((A1.Text == "O") && (B1.Text == "O") && (C1.Text == "O") && (!A1.Enabled))
                ganador = true;
            else if ((A2.Text == "O") && (B2.Text == "O") && (C2.Text == "O") && (!A2.Enabled))
                ganador = true;
            else if ((A3.Text == "O") && (B3.Text == "O") && (C3.Text == "O") && (!A3.Enabled))
                ganador = true;
            if (ganador)    //CUANDO ALGUIEN GANA
            {
                
                //DesactivarBotones();
               // string mensaje = "15/" + menu.PonUsuario;
                //EnviaMensajeServidor(mensaje);
                
                MessageBox.Show(" Has ganado!");
                this.Close();

            }//fin if ganador
            else                //SI HAY NUEVE TIRADAS(EMPAT)
            {
                if (ekis_count == 9)
                    MessageBox.Show("Vuelve a intentarlo...");
            }

        }//fin ganador

 //Funciones que nos permite acceso al menu
        public string TextoBotonA1 { get { return A1.Text; } }
        public string TextoBotonA2 { get { return A2.Text; } }
        public string TextoBotonA3 { get { return A1.Text; } }
        public string TextoBotonB1 { get { return A2.Text; } }
        public string TextoBotonB2 { get { return A1.Text; } }
        public string TextoBotonB3 { get { return A2.Text; } }
        public string TextoBotonC1 { get { return A1.Text; } }
        public string TextoBotonC2 { get { return A2.Text; } }
        public string TextoBotonC3 { get { return A1.Text; } }

        public string PonA1 { set { A1.Text = value; } }
        public string PonA2 { set { A2.Text = value; } }
        public string PonA3 { set { A3.Text = value; } }
        public string PonB1 { set { B1.Text = value; } }
        public string PonB2 { set { B2.Text = value; } }
        public string PonB3 { set { B3.Text = value; } }
        public string PonC1 { set { C1.Text = value; } }
        public string PonC2 { set { C2.Text = value; } }
        public string PonC3 { set { C3.Text = value; } }

        //Permitimos acceder al estado de las fichas 

        public bool EstadoA1 { set { A1.Enabled = value; } }
        public bool EstadoA2 { set { A2.Enabled = value; } }
        public bool EstadoA3 { set { A3.Enabled = value; } }
        public bool EstadoB1 { set { B1.Enabled = value; } }
        public bool EstadoB2 { set { B2.Enabled = value; } }
        public bool EstadoB3 { set { B3.Enabled = value; } }
        public bool EstadoC1 { set { C1.Enabled = value; } }
        public bool EstadoC2 { set { C2.Enabled = value; } }
        public bool EstadoC3 { set { C3.Enabled = value; } }


        public void EnviaMensajeServidor(string mensaje)
        {
            //metodo para enviar mensajes al servidor desde este formulario 

            try
            {
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }

            catch(Exception ex)
            {
                MessageBox.Show("Error al enviar mensaje al servidor: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public delegate void ActualizarTableroEventHandler(string posicion);
        public event ActualizarTableroEventHandler ActualizarTableroEvent;



    }

 }
