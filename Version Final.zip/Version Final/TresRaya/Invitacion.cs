﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TresRaya
{
    public partial class Invitacion : Form
    {
        // Variables globales
        int resp;
        public Invitacion()
        {
            InitializeComponent();
        }
      
        public int GetResp()
        {
            return this.resp;
        }
       
        private void button2_Click(object sender, EventArgs e)
        {
            this.resp = 1;
            this.Close();
        }

        private void aceptar_Click_1(object sender, EventArgs e)
        {
            this.resp = 0;
            this.Close();

        }

        private void Invitacion_Load(object sender, EventArgs e)
        {

        }
    }
}
